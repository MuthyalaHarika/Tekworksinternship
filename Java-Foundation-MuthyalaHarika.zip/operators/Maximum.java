import java.util.Scanner;
class Maximum
  {
    public static void main(String args[])
    {
      int i,j;
      Scanner k=new Scanner(System.in);
      i=k.nextInt();
      j=k.nextInt();
      if(i>=j)
        System.out.println("i is maximum");
      else
        System.out.println("j is maximum");
      
    }
  }