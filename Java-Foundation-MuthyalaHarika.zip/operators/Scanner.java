import java.util.Scanner; //import packages
class Hello
  {
    public static void main(String arg[])
    
    {
      int x;char y;double z;String h ; //default data type is double; //to different inputs to any variable //we use input method
  class scanner
    }
