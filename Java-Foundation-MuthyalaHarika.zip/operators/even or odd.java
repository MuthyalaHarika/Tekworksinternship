import java.util.Scanner;
  class even or odd
    {
    public static void main(String arg[])
      {
      int a;
      Scanner d=new Scanner(System.in);
      a=d.nrxtInt();
      if(a%2==0)
        System.out.println("a is an even number");
      else
        System.out.println("a is an odd number");
      }
    }