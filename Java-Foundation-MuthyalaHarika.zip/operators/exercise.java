import java.Scanner;
  class M
    {
      public static void main(String arg[])
      {
      int i,j;
     Scanner m=new Scanner(system.in);
        {
       i=nextInt();
       j=nextInt();
      if(i<j)
  System.out.println("i is a maximum number");
else
    System.out.println("j is a maximum number");

      }
    }

      
      
      
    

    